function toggle_open_branch(branch_box, toggle_box, branch_title){
    
        branch = document.getElementById(branch_box);
    
        if(branch != null && branch.style.display == 'none'){
            branch.style.display = 'grid';
            toggle_box.innerHTML='<i class="fa fa-angle-up fa-lg" aria-hidden="true"></i> ' + branch_title + ' <i class="fa fa-angle-up fa-lg" aria-hidden="true"></i>';
        }else{
            branch.style.display = 'none';
            toggle_box.innerHTML='<i class="fa fa-angle-down fa-lg" aria-hidden="true"></i> ' + branch_title + ' <i class="fa fa-angle-down fa-lg" aria-hidden="true"></i>';
        }
    }