function fazerLogin() {
    const usuario = document.getElementById('usuario').value;
    const senha = document.getElementById('senha').value;
    const mensagem = document.getElementById('mensagemLogin');

    const dados = JSON.parse(localStorage.getItem('usuarios')) || {};

    if (dados[usuario] && dados[usuario] === senha) {
        mensagem.style.color = 'lightgreen';
        mensagem.textContent = 'Login bem-sucedido!';
    } else {
        mensagem.style.color = '#ff5050';
        mensagem.textContent = 'Usuário ou senha incorretos.';
    }
}

function cadastrarUsuario() {
    const usuario = document.getElementById('usuario').value;
    const senha = document.getElementById('senha').value;
    const mensagem = document.getElementById('mensagemLogin');

    if (!usuario || !senha) {
        mensagem.style.color = '#ff5050';
        mensagem.textContent = 'Preencha usuário e senha.';
        return;
    }
    const dados = JSON.parse(localStorage.getItem('usuarios')) || {};

    if (dados[usuario]) {
        mensagem.style.color = '#ff5050';
        mensagem.textContent = 'Usuário já existe.';
    } else {
        dados[usuario] = senha;
        localStorage.setItem('usuarios', JSON.stringify(dados));
        mensagem.style.color = 'lightgreen';
        mensagem.textContent = 'Usuário cadastrado com sucesso!';
    }
}

function alternarMusica() {
  const musica = document.getElementById('musicaFundo');
  const botao = document.getElementById('botaoMusica');

  if (musica.paused) {
    musica.play();
    botao.textContent = '🔊 Pausar Música';
  } else {
    musica.pause();
    botao.textContent = '🔈 Tocar Música';
  }
}

const evolucoes = {
  'Espadachim': ['Cavaleiro / Cruzado', 'Lord / Paladino', 'Cav.Rúnico / Guard.Real', 'Cav.Dragôniano / Guar.Imperial'],
  'Mago': ['Bruxo / Sábio', 'Arcano / Feiticeiro', 'Mestre Mágico / Mestre Elemental'],
  'Arqueiro': ['Caçador / Atirador', 'Bardo / Odalisca', 'Sentinela/Minestrel/Musa', 'Windhawk/Maestro/Bailarina'],
  'Mercador': ['Ferreiro', 'Alquimista / Criador', 'Mecânico / Bioquímico', 'Mestre de Forjas / Biólogo'],
  'Gatuno': ['Mercenário / Arruaceiro', 'Sicário / Renegado', 'Arauto / Abisal'],
  'Noviço': ['Monge / Sacerdote', 'Arcebispo / Shura', 'Cardeal / Inquisitor'],
  'Aprendiz': ['Super Aprendiz', 'Super Aprendiz Expandido'],
  'Taekwon': ['Gladiador Estelar/ Espiritualista', 'Imp.Estelar / Lad.de Almas'],
  'Ninja': ['Kagerou / Oboro', 'Shinkiro / Shiranui'],
  'Justiceiro': ['Insurgente', 'Night Watch'],
  'Doran': ['Doran Invocador', 'Doran Espiritualista']


};

document.querySelectorAll('.card').forEach(card => {
  card.addEventListener('click', () => {
    const classe = card.querySelector('h3').textContent;
    const evol = evolucoes[classe];
    if (evol) {
      document.getElementById('tituloClasse').textContent = `Evoluções de ${classe}`;
      const lista = document.getElementById('listaEvolucoes');
      lista.innerHTML = '';
      evol.forEach(e => {
        const li = document.createElement('li');
        li.textContent = e;
        lista.appendChild(li);
      });
      document.getElementById('modal').style.display = 'flex';
    }
  });
});

document.getElementById('fechar').onclick = () => {
  document.getElementById('modal').style.display = 'none';
};

window.onclick = e => {
  if (e.target.id === 'modal') {
    document.getElementById('modal').style.display = 'none';
  }
};
